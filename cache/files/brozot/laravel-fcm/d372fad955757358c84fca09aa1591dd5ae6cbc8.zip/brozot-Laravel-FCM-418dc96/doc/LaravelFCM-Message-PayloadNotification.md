LaravelFCM\Message\PayloadNotification
===============

Class PayloadNotification




* Class name: PayloadNotification
* Namespace: LaravelFCM\Message
* This class implements: Illuminate\Contracts\Support\Arrayable






Methods
-------


### __construct

    mixed LaravelFCM\Message\PayloadNotification::__construct(\LaravelFCM\Message\PayloadNotificationBuilder $builder)

PayloadNotification constructor.



* Visibility: **public**


#### Arguments
* $builder **[LaravelFCM\Message\PayloadNotificationBuilder](LaravelFCM-Message-PayloadNotificationBuilder.md)**



### toArray

    array LaravelFCM\Message\PayloadNotification::toArray()

convert PayloadNotification to array



* Visibility: **public**



